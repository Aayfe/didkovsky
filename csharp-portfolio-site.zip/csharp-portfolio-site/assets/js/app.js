/* ===== Icons ===== */
document.addEventListener("DOMContentLoaded", () => {
  if (window.lucide) window.lucide.createIcons();
});

/* ===== Smooth Scroll via Lenis ===== */
let lenis;
window.addEventListener("load", () => {
  if (window.Lenis) {
    lenis = new Lenis({ smoothWheel: true, smoothTouch: false, duration: 1.2 });
    function raf(time){ lenis.raf(time); requestAnimationFrame(raf); }
    requestAnimationFrame(raf);
  }
});

/* ===== Mobile nav ===== */
const navToggle = document.querySelector(".nav-toggle");
const navList = document.querySelector(".nav-list");
if (navToggle && navList) {
  navToggle.addEventListener("click", () => {
    const isOpen = navList.classList.toggle("open");
    navToggle.setAttribute("aria-expanded", String(isOpen));
  });
  navList.querySelectorAll("a").forEach(a => a.addEventListener("click", () => {
    navList.classList.remove("open");
    navToggle.setAttribute("aria-expanded", "false");
  }));
}

/* ===== Year ===== */
document.getElementById("year").textContent = new Date().getFullYear();

/* ===== Projects data & render ===== */
const projects = [
  {
    title: "Inventory Manager",
    desc: "Backend v C# .NET s SQL databází pro správu skladových zásob.",
    tags: ["csharp", "sql", "api"],
    link: "https://github.com/janedoe/inventory-manager"
  },
  {
    title: "Rezervační systém",
    desc: "ASP.NET MVC s optimalizovanými SQL dotazy a responzivním webem.",
    tags: ["csharp", "web", "sql"],
    link: "https://github.com/janedoe/reservation-app"
  },
  {
    title: "Report Automation",
    desc: "C# skript pro export dat do Excelu + plánování běhů.",
    tags: ["csharp", "sql"],
    link: "https://github.com/janedoe/report-automation"
  },
  {
    title: "Monitoring API",
    desc: "REST API v .NET 8 + EF Core + JWT auth.",
    tags: ["csharp", "api", "web"],
    link: "https://github.com/janedoe/monitoring-api"
  },
  {
    title: "Analytics Dashboard",
    desc: "Lehký dashboard s fetch API a grafy.",
    tags: ["web"],
    link: "https://github.com/janedoe/analytics-dashboard"
  },
  {
    title: "DB Optimizer",
    desc: "Nástroj pro profilování dotazů a návrh indexů.",
    tags: ["sql"],
    link: "https://github.com/janedoe/db-optimizer"
  }
];

const grid = document.querySelector(".projects-grid");
function renderProjects(filter = "all"){
  grid.innerHTML = "";
  const filtered = projects.filter(p => filter==="all" ? true : p.tags.includes(filter));
  filtered.forEach(p => {
    const el = document.createElement("article");
    el.className = "card project reveal";
    el.innerHTML = `
      <h3>${p.title}</h3>
      <p class="muted">${p.desc}</p>
      <div class="meta">${p.tags.map(t=>`<span class="tag">${t}</span>`).join("")}</div>
      <div class="card-actions">
        <a class="btn btn-accent" target="_blank" rel="noreferrer" href="${p.link}"><i data-lucide="github"></i> Zdroj</a>
        <button class="btn btn-ghost more"><i data-lucide="sparkles"></i> Detail</button>
      </div>
    `;
    grid.appendChild(el);
  });
  if (window.lucide) window.lucide.createIcons();
  initReveals();
}
renderProjects();

/* ===== Filters ===== */
document.querySelectorAll(".filter").forEach(btn => {
  btn.addEventListener("click", () => {
    document.querySelectorAll(".filter").forEach(b => b.classList.remove("active"));
    btn.classList.add("active");
    renderProjects(btn.dataset.filter);
  });
});

/* ===== Contact form (client-side) ===== */
const form = document.getElementById("contactForm");
const statusEl = document.getElementById("formStatus");
function setInvalid(field, invalid){
  field.closest(".field").classList.toggle("invalid", invalid);
}
function validateEmail(v){
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v);
}
if (form){
  form.addEventListener("submit", (e) => {
    e.preventDefault();
    const name = form.name.value.trim();
    const email = form.email.value.trim();
    const msg = form.msg.value.trim();

    let ok = true;
    setInvalid(form.name, !name);
    setInvalid(form.email, !validateEmail(email));
    setInvalid(form.msg, !msg);

    ok = name && validateEmail(email) && msg;

    if (ok){
      statusEl.textContent = "Díky! Zpráva byla připravena v e-mailu.";
      statusEl.style.color = "var(--green)";
      // mailto fallback
      const subject = encodeURIComponent("Poptávka z webu — C#/.NET");
      const body = encodeURIComponent(`Jméno: ${name}\nEmail: ${email}\n\n${msg}`);
      window.location.href = `mailto:developer@example.com?subject=${subject}&body=${body}`;
      form.reset();
    } else {
      statusEl.textContent = "Zkontrolujte prosím vyplněná pole.";
      statusEl.style.color = "#ff6b6b";
    }
  });
}

/* ===== Download CV (generate simple PDF using canvas) ===== */
document.getElementById("downloadCv")?.addEventListener("click", async () => {
  // Simple PDF via canvas -> image -> open in new tab
  const w = 794, h = 1123; // A4 @ 96dpi approx
  const cv = document.createElement("canvas");
  cv.width = w; cv.height = h;
  const ctx = cv.getContext("2d");
  // background
  const grad = ctx.createLinearGradient(0,0,w,0);
  grad.addColorStop(0, "#1a1c20"); grad.addColorStop(1, "#0a0b0c");
  ctx.fillStyle = grad; ctx.fillRect(0,0,w,h);
  // title
  ctx.fillStyle = "#fff"; ctx.font = "bold 32px Inter";
  ctx.fillText("C#/.NET Developer — CV", 40, 60);
  ctx.font = "16px Inter"; ctx.fillStyle = "#9aa4ad";
  ctx.fillText("Email: developer@example.com | Tel: +420 123 456 789", 40, 90);
  // skills
  const skills = ["C#", ".NET 8", "ASP.NET", "EF Core", "SQL Server", "PostgreSQL", "Docker", "Azure", "CI/CD"];
  ctx.fillStyle = "#fff"; ctx.font = "bold 20px Inter"; ctx.fillText("Dovednosti", 40, 140);
  ctx.font = "16px Inter"; ctx.fillStyle = "#d7dde3";
  skills.forEach((s, i)=> ctx.fillText("• "+s, 40, 170 + i*22));
  // footer
  ctx.fillStyle = "#fff700"; ctx.font = "bold 14px Inter"; ctx.fillText("Vygenerováno z portfolia", 40, h-40);
  const url = cv.toDataURL("image/png");
  const a = document.createElement("a");
  a.href = url; a.download = "CV.png"; a.click();
});

/* ===== Reveal on scroll (IntersectionObserver) ===== */
let revealObserver;
function initReveals(){
  if (!revealObserver){
    revealObserver = new IntersectionObserver((entries)=>{
      entries.forEach(e=>{
        if (e.isIntersecting){
          e.target.classList.add("in");
          revealObserver.unobserve(e.target);
        }
      });
    }, { threshold: .2 });
  }
  document.querySelectorAll(".reveal").forEach(el => revealObserver.observe(el));
}
// bars animation once revealed
function animateBars(){
  document.querySelectorAll(".bars .bar i").forEach(i => {
    i.animate([{ transform:"scaleX(0)" }, { transform:"scaleX(1)" }], { duration: 900, easing: "cubic-bezier(.2,.8,.2,1)", fill:"forwards" });
  });
}
window.addEventListener("load", () => {
  initReveals();
  setTimeout(animateBars, 300);
});

/* ===== GSAP niceties ===== */
window.addEventListener("load", () => {
  if (!window.gsap) return;
  const gsap = window.gsap;
  const st = window.ScrollTrigger;

  gsap.from(".hero-title .gradient", { opacity:0, y:20, duration:.8, ease:"power3.out" });
  gsap.from(".hero-cta .btn", { opacity:0, y:10, duration:.4, stagger:.1, ease:"power2.out" });
  gsap.from(".hero-stats .num", { innerText:0, duration:1.4, snap:{innerText:1}, stagger:.2, ease:"power1.out" });

  gsap.utils.toArray(".section-title").forEach(t => {
    gsap.from(t, { scrollTrigger:{ trigger:t, start:"top 85%" }, y:20, opacity:0, duration:.5 });
  });
});

/* ===== Spray/Graffiti background canvas ===== */
const canvas = document.getElementById("sprayCanvas");
const ctx = canvas.getContext("2d", { alpha: true });
const DPR = Math.min(window.devicePixelRatio || 1, 2);
let W, H;
function resizeCanvas(){
  W = canvas.width = Math.floor(innerWidth * DPR);
  H = canvas.height = Math.floor(innerHeight * DPR);
  canvas.style.width = innerWidth+"px";
  canvas.style.height = innerHeight+"px";
}
resizeCanvas();
addEventListener("resize", resizeCanvas);

const palette = ["#ff3cac", "#ff7e00", "#00ff85", "#fff700"];
const sprays = [];
function addSpray(x, y){
  for (let i=0;i<40;i++){
    sprays.push({
      x: x*DPR, y: y*DPR,
      vx: (Math.random()-0.5) * 2,
      vy: (Math.random()-0.5) * 2,
      life: Math.random()*80 + 40,
      r: Math.random()*2 + 0.5,
      c: palette[Math.floor(Math.random()*palette.length)]
    });
  }
}
let lastT=0;
function tick(t){
  requestAnimationFrame(tick);
  const dt = Math.min(33, t - lastT); lastT=t;
  ctx.clearRect(0,0,W,H);
  sprays.forEach(s => {
    s.x += s.vx; s.y += s.vy; s.life -= dt*.06;
    const alpha = Math.max(0, Math.min(1, s.life/100));
    ctx.beginPath();
    ctx.fillStyle = s.c + Math.floor(alpha*255).toString(16).padStart(2,"0");
    ctx.arc(s.x, s.y, s.r*DPR, 0, Math.PI*2);
    ctx.fill();
  });
  for (let i=sprays.length-1;i>=0;i--){
    if (sprays[i].life<=0) sprays.splice(i,1);
  }
}
requestAnimationFrame(tick);
addEventListener("pointermove", (e)=> addSpray(e.clientX, e.clientY));

/* ===== Small helpers ===== */
document.querySelectorAll('a[href^="#"]').forEach(a => {
  a.addEventListener("click", (e) => {
    const id = a.getAttribute("href").slice(1);
    const target = document.getElementById(id);
    if (target){
      e.preventDefault();
      target.scrollIntoView({ behavior: "smooth", block: "start" });
    }
  });
});
